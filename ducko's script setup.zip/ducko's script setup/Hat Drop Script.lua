--// source: https://v3rmillion.net/showthread.php?tid=990434
--// credits: Hat Drop Script by eringj.

loadstring(game:HttpGetAsync("https://pastebin.com/raw/ZJqXnz6e"))()