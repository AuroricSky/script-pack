--// source: https://v3rmillion.net/showthread.php?tid=1010821
--// credits: Fencing Fast-Swing by jacob.

local toolname = "Foil"
local swingtime = 0.0
if game.Players.LocalPlayer.Character:FindFirstChild(toolname) then
    tool = game.Players.LocalPlayer.Character[toolname]
else
    if game.Players.LocalPlayer.Backpack:FindFirstChild(toolname) then
        tool = game.Players.LocalPlayer.Backpack[toolname]
    end
end
tool.ToolTip = "[void] fast swing"
function swordUp()
    tool.GripForward = Vector3.new(-1,0,0)
    tool.GripRight = Vector3.new(0,1,0)
    tool.GripUp = Vector3.new(0,0,1)
end
function swordOut()
    tool.GripForward = Vector3.new(0,0,1)
    tool.GripRight = Vector3.new(0,-1,0)
    tool.GripUp = Vector3.new(-1,0,0)
end
function fastswing()
    swordOut()
    wait(swingtime)
    swordUp()
end
tool.Activated:connect(fastswing)