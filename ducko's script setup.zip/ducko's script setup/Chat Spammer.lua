--// source: https://robloxscripts.com/chat-spam-script/
--// credits: unknown.
--// edit "bruh moment" with the thing you want to to spam in chat.

while true do wait(1) 

local A_1 = "bruh moment" local A_2 = "All" 
local Event = game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest Event:FireServer(A_1, A_2) end