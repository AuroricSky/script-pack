--// simpleCheats GUI by @ducko#0415.
--// source: https://github.com/du3ko/guis/blob/master/simpleCheats.lua
--// alternative loadstring if pastebin chokes: loadstring(game:HttpGet("https://raw.githubusercontent.com/du3ko/guis/master/simpleCheats.lua", true))()

loadstring(game:HttpGet("https://pastebin.com/raw/cUvMssVP", true))()