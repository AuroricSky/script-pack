--// source: https://v3rmillion.net/showthread.php?tid=1003168
--// Synapse X Chat Logger by e621 but modified by me (ducko).
--// only works with Synapse X, since it uses the Synapse X rconsole.

repeat wait() until game:IsLoaded()

if not getgenv().executed then
    spawn(function()
        for i,qu3ck in pairs(game.Players:GetChildren()) do
            qu3ck.Chatted:Connect(function(ch3t)
                if ch3t:sub(1,2):lower() == "/w" then
                    rconsoleprint("@@CYAN@@")
                    rconsoleprint(tostring("Private Message: " ..qu3ck.name ..": ") ..ch3t .."\n")
                elseif ch3t:sub(1,2):lower() == "/e" then
                    rconsoleprint("@@BROWN@@")
                    rconsoleprint(tostring("Emote: " ..qu3ck.name ..": ") ..ch3t .."\n")
                else
                    rconsoleprint("@@WHITE@@")
                    rconsoleprint(tostring(qu3ck.Name ..": ") ..ch3t .."\n")
                end
            end)
        end
        game.Players.PlayerAdded:Connect(function(maker)
            p = maker
            if p.UserId == game.CreatorId or p:IsFriendsWith(tonumber(game.CreatorId)) then
                rconsoleprint("@@YELLOW@@")
                rconsoleprint(tostring("GAME OWNER OR ADMIN" ..tostring(p.Name) .." Joined!, Userid: " ..tostring(p.UserId) ..", AccountAge: " ..tostring(p.AccountAge) .."\n"))
                else
            rconsoleprint("@@GREEN@@")
            rconsoleprint(tostring(tostring(p.Name) .." Joined!, Userid: " ..tostring(p.UserId) ..", AccountAge: " ..tostring(p.AccountAge) .."\n"))
            maker.Chatted:Connect(function(bruhmoment)
                if bruhmoment:sub(1,2):lower() == "/w" then
                    rconsoleprint("@@CYAN@@")
                    rconsoleprint(tostring("Private Message: " ..maker.name ..": ") ..bruhmoment .."\n")
                elseif bruhmoment:sub(1,2):lower() == "/e" then
                    rconsoleprint("@@BROWN@@")
                    rconsoleprint(tostring("Emote: " ..maker.name ..": ") ..bruhmoment .."\n")
                else
                    rconsoleprint("@@WHITE@@")
                    rconsoleprint(tostring(maker.Name ..": ") ..bruhmoment .."\n")
                end
            end)
        end
        end)
    end)
            rconsoleprint("@@GREEN@@")
            rconsoleprint("Loaded! \n")
game.Players.PlayerRemoving:Connect(function(charmander)
    wait (1.5)
    rconsoleprint("@@RED@@")
    rconsoleprint(tostring(charmander) .." Left!" .."\n")
end)
    getgenv().executed = true
else
    rconsoleprint("@@RED@@")
    rconsoleprint("Already Executed!" .."\n")
end