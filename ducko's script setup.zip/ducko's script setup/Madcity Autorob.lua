--// source: https://v3rmillion.net/showthread.php?tid=1035036
--// credits: Madcity Autorob by ToastedShoes.
--// Put this in your Autoexec folder!

loadstring(game:HttpGet("https://raw.githubusercontent.com/ToastedShoes/MadCityAR/master/ServerHop",true))()