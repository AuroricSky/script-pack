--// source: https://v3rmillion.net/showthread.php?tid=1039995
--// credits: Stay alive and flex your time on others GUI by coolman742.
--// i saw a koneko video on this game and thought it was cool.

loadstring(game:HttpGet("https://pastebin.com/raw/rvDZEVKn"))()