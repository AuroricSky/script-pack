--// i don't know where i got this script from, but its a pretty nice Anti AFK and one of only few that work from what i can see.

repeat wait(0.1) until game:GetService("Players").LocalPlayer wait(2)

game:GetService("Players").LocalPlayer.Idled:connect(function()
	game:GetService("VirtualUser"):CaptureController()
	game:GetService("VirtualUser"):ClickButton2(Vector2.new())
end)