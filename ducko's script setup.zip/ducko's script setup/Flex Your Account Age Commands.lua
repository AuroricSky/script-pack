--// source: https://v3rmillion.net/showthread.php?tid=1040115
--// credits: Flex Your Account Age Commands by Twitter.
--[[
A gui that bypass any blacklisted audio ( yes ik its so weird they blacklist bypassed audios lmao )
and a Staff detector , if any staff join the game u get a alert ( wont work if the staff was already ingame before you joined )
--- Cmds ---

( v its basic stuff ik no need to say it v )

/e unlock [ to unlock every rooms ]

/e rj [ to rejoin the game ]

/e sit

/e r [ to reset ]

/e noface or /e faceless

/e s or /e sword [ to get a sword ]

/e x [ You need the boombox gamepass for this , literally if u press X u instant respawn with no delay DONT HOLD ANYTHING IN UR HANDS BEFORE PRESSING X 
]]--

loadstring(game:HttpGet(('https://pastebin.com/raw/fvtfGKec'),true))()