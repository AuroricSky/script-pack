--// source: https://v3rmillion.net/showthread.php?tid=955312
--// credits: Unanchored Parts To Player GUI by TomQ#6764.

loadstring(game:HttpGet("https://pastebin.com/raw/FYxcrR3i", true))()