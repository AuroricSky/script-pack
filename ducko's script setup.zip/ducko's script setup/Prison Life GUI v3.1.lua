--// source: https://youtu.be/lSryfxwCffg
--// credits: Prison Life GUI v3.1 by Jmuse.
--// has good features that sets it back from prevail x.

loadstring(game:HttpGet("https://raw.githubusercontent.com/RbxCheats/RbxCheats/master/Scripts/PLG%20v3.1.lua",true))()