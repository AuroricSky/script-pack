--// source: https://raw.githubusercontent.com/exxtremestuffs/SimpleSpySource/
--// Credits: 
--// exxtremestuffs - basically everything
--// Frosty - GUI to Lua

loadstring(game:HttpGet("https://github.com/exxtremestuffs/SimpleSpySource/raw/master/SimpleSpy.lua"))()