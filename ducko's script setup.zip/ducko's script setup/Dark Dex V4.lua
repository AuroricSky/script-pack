--// source: https://v3rmillion.net/showthread.php?tid=1032423
--// credits: Dark Dex V4 by Attribute.
--// yea ik more people worked on it, im just listing the v3rm poster.

loadstring(game:HttpGetAsync("https://pastebin.com/raw/fPP8bZ8Z"))()