--// Specific scripts in this GUI found here: https://v3rmillion.net/showthread.php?tid=809402, https://v3rmillion.net/showthread.php?tid=709985.
--// Natural Disaster Survival GUI made by ducko#0415.
--// Alternative loadstring if pastebin is down or whatever: loadstring(game:HttpGet("https://raw.githubusercontent.com/du3ko/guis/master/Natural%20Disaster%20Survival%20GUI.lua", true))()

loadstring(game:HttpGet("https://pastebin.com/raw/h30Wpg2N", true))()