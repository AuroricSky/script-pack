--// source: https://v3rmillion.net/showthread.php?tid=980945
--// credits: Aimbot by herrtt.

pcall(function()
   loadstring(game:HttpGet("https://raw.githubusercontent.com/Herrtt/AimHot-v8/master/Main.lua", true))()
end)