--// source: https://v3rmillion.net/showthread.php?tid=1012881
--// credits: BIG Paintball GUI by Averias.

loadstring(game:HttpGetAsync("https://pastebin.com/raw/pgnigYpu"))()