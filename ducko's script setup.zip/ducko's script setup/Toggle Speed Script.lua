--// Toggle Speed Script
--// Q to slow down
--// E to speed up
--// idk where i got this from lol.

local UIS = game:GetService("UserInputService")

UIS.InputBegan:Connect(function(input)
    if input.keyCode == Enum.KeyCode.E
    then
		game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = game.Players.LocalPlayer.Character.Humanoid.WalkSpeed + 5
	elseif input.keyCode == Enum.KeyCode.Q
	then
		game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = game.Players.LocalPlayer.Character.Humanoid.WalkSpeed - 5
    end
end)