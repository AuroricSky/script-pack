--// Toggle Speed Script
--// B to slow down
--// V to speed up
--// idk where i got this from lol.

local UIS = game:GetService("UserInputService")

UIS.InputBegan:Connect(function(input)
    if input.keyCode == Enum.KeyCode.V
    then
		game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = game.Players.LocalPlayer.Character.Humanoid.WalkSpeed + 5
	elseif input.keyCode == Enum.KeyCode.B
	then
		game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = game.Players.LocalPlayer.Character.Humanoid.WalkSpeed - 5
    end
end)