--// source: discord.gg/krnl in #update-logs.
--// credits: Phantom Forces GUI by Insane.
--// better than some paid hub phantom forces gui's.

loadstring(game:HttpGet("https://pastebin.com/raw/NjTdrExi"))()