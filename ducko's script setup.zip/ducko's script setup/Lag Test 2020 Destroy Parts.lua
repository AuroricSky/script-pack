--// source: https://v3rmillion.net/showthread.php?tid=1020121
--// credits: Lag Test 2020 Destroy Parts by CrisTGLXLogo.
--// Game Link: https://www.roblox.com/games/4778989425/
--[[
how to use:
Step 1. Load into the game
Step 2. when your executor is injected and the script is ready to execute start loading in parts wait for 200 parts or more to load
Step 3. Execute the script
there you go no new parts should load.
]]--

while wait() do
   game.workspace.LagParts.LagPart:Destroy()
end