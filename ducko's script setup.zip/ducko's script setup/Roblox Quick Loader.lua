--// source: https://v3rmillion.net/showthread.php?tid=1022621
--// credits: Roblox Quick Loader by BeachBear.
--[[
Tutorial:
1: Put this file in your auto execute folder.
2: Join any game and you should see a gui, that means it's working and you're finished!
Chat Commands:
"/re": Resets you then teleports you back to your original position.
"/rj": Rejoins your same server. (Only works if there's 2 or more people in your server.)
"/rjnew": Rejoins a random server.
(This is also open source so feel free to change the prefix, command names etc.)
]]--

loadstring(game:HttpGet("https://pastebin.com/raw/QNMtmpPU", true))()