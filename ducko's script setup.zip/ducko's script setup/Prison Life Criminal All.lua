--// Made by Jake11price

--// modified this script so it would give people ak-47's instead of trash m9's.

--// source: https://pastebin.com/raw/aiNDd7Js.

local Crim = Instance.new("Part")
   Crim.Name = "plr"
     Crim.Parent = workspace
       Crim.Anchored = true
         Crim.Archivable = true
      Crim.CFrame = CFrame.new(9e99, 9e99, 9e99)
   Bruh = game.Workspace["Criminals Spawn"].SpawnLocation
local gui = Instance.new("ScreenGui")
local main = Instance.new("Frame")
local Bringmain = Instance.new("Frame")
local Credits = Instance.new("TextLabel")
local Bringoffmain = Instance.new("Frame")
local Bringoff = Instance.new("TextButton")

gui.Name = "gui"
gui.Parent = game.CoreGui

main.Name = "main"
main.Parent = gui
main.BackgroundColor3 = Color3.new(0, 0, 0)
main.Position = UDim2.new(0.132017255, 0, 0.617936134, 0)
main.Size = UDim2.new(0, 161, 0, 100)
main.Active = true
main.Draggable = true

Bringmain.Name = "Bringmain"
Bringmain.Parent = main
Bringmain.BackgroundColor3 = Color3.new(0, 0, 0)
Bringmain.Position = UDim2.new(0, 0, -0.100000001, 0)
Bringmain.Size = UDim2.new(0, 161, 0, 110)

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer
local function RemoveSpaces(String)
	return String:gsub("%s+", "") or String
end

local function FindPlayer(String)
	String = RemoveSpaces(String)
	for _, _Player in pairs(Players:GetPlayers()) do
		if _Player.Name:lower():match('^'.. String:lower()) then
			return _Player
		end
	end
	return nil
end

Credits.Name = "Credits"
Credits.Parent = Bringmain
Credits.BackgroundColor3 = Color3.new(0.333333, 1, 0)
Credits.Size = UDim2.new(0, 161, 0, 25)
Credits.Font = Enum.Font.GothamBold
Credits.Text = "JAKE11PRICE"
Credits.TextColor3 = Color3.new(0, 0, 0)
Credits.TextSize = 14

Bringoffmain.Name = "Bringoffmain"
Bringoffmain.Parent = Bringmain
Bringoffmain.BackgroundColor3 = Color3.new(1, 1, 1)
Bringoffmain.Position = UDim2.new(0, 0, 0.609090924, 0)
Bringoffmain.Size = UDim2.new(0, 161, 0, 43)

Bringoff.Name = "Bringoff"
Bringoff.Parent = Bringoffmain
Bringoff.BackgroundColor3 = Color3.new(0.333333, 1, 0)
Bringoff.Position = UDim2.new(-0.00621099072, 0, 0, 0)
Bringoff.Size = UDim2.new(0, 161, 0, 43)
Bringoff.Font = Enum.Font.Highway
Bringoff.Text = "Bring all/Crim All"
Bringoff.TextColor3 = Color3.new(0, 0, 0)
Bringoff.TextSize = 14
Bringoff.MouseButton1Down:connect(function()
NOW = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
_G.Crimall = true
local Player = game.Players.LocalPlayer
local cpos = Player.Character.HumanoidRootPart.CFrame
for i,v in pairs(game.Teams.Guards:GetPlayers()) do
if v and v.Character then
if v.Name ~= Player.Name then
if v.Name ~= "jake11price" then
    repeat
    i = i-1
	repeat
if v.Character.Humanoid.Sit == true then 
game.Workspace.Remote.ItemHandler:InvokeServer(workspace.Prison_ITEMS.giver["Remington 870"].ITEMPICKUP) 
local A_1 = 
{
	[1] = 
{
	["RayObject"] = Ray.new(Vector3.new(827.412415, 101.489777, 2296.84326), Vector3.new(277.738678, 6.89340925, 287.773712)), 
	["Distance"] = 4.7204174995422, 
	["Cframe"] = CFrame.new(832.049377, 101.392006, 2300.97168, 0.843892097, -0.0554918349, 0.533635378, 0, 0.994636595, 0.103430569, -0.536512911, -0.0872842371, 0.839366019), 
	["Hit"] = v.Character.Head
}, 
	[2] = 
{
	["RayObject"] = Ray.new(Vector3.new(827.412415, 101.489777, 2296.84326), Vector3.new(303.047546, 21.3568707, 260.203888)), 
	["Distance"] = 4.8114862442017, 
	["Cframe"] = CFrame.new(832.390259, 101.550629, 2300.74097, 0.738044441, -0.112958886, 0.665229917, 7.45057971e-09, 0.985887885, 0.16740793, -0.674752235, -0.123554483, 0.727628946), 
	["Hit"] = v.Character.Head
}, 
	[3] = 
{
	["RayObject"] = Ray.new(Vector3.new(827.412415, 101.489777, 2296.84326), Vector3.new(296.800507, 7.00420141, 268.067932)), 
	["Distance"] = 4.444625377655, 
	["Cframe"] = CFrame.new(832.185486, 101.391617, 2300.70264, 0.775115669, -0.0692948848, 0.628007889, 7.45057971e-09, 0.993967533, 0.109675139, -0.631819367, -0.0850109085, 0.770439863), 
	["Hit"] = v.Character.Head
}, 
	[4] = 
{
	["RayObject"] = Ray.new(Vector3.new(827.412415, 101.489777, 2296.84326), Vector3.new(284.930573, 11.9850616, 280.483368)), 
	["Distance"] = 4.6211166381836, 
	["Cframe"] = CFrame.new(832.10083, 101.445007, 2300.86963, 0.820150614, -0.0735745132, 0.567397356, 0, 0.991697431, 0.128593579, -0.572147667, -0.105466105, 0.81334126), 
	["Hit"] = v.Character.Head
}, 
	[5] = 
{
	["RayObject"] = Ray.new(Vector3.new(827.412415, 101.489777, 2296.84326), Vector3.new(294.625824, 2.15741801, 270.538269)), 
	["Distance"] = 4.4639973640442, 
	["Cframe"] = CFrame.new(832.169434, 101.341301, 2300.73438, 0.784266233, -0.0537625961, 0.618090749, -3.7252903e-09, 0.99623847, 0.086654529, -0.620424569, -0.0679602176, 0.781316102), 
	["Hit"] = v.Character.Head
}
}
local A_2 = game.Players.LocalPlayer.Backpack["Remington 870"]
local Event = game:GetService("ReplicatedStorage").ShootEvent
Event:FireServer(A_1, A_2)
Event:FireServer(A_1, A_2)
Event:FireServer(A_1, A_2)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.Character.HumanoidRootPart.CFrame
wait(0.3)
local Crim = Instance.new("Part")
   Crim.Name = "plr"
     Crim.Parent = workspace
       Crim.Anchored = true
         Crim.Archivable = true
      Crim.CFrame = CFrame.new(9e99, 9e99, 9e99)
   Bruh = game.Workspace["Criminals Spawn"].SpawnLocation
Crim.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
	Crim.Transparency = 1
	    Crim.Anchored = true
	 Crim.CanCollide = false
  lol = true				
Bruh = game.Workspace["Criminals Spawn"].SpawnLocation
  Bruh.CanCollide = false
      Bruh.Size = Vector3.new(51.05, 24.12, 54.76)
	Bruh.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
  Bruh.Transparency = 1
  game.Players.LocalPlayer.Character.Humanoid.Sit = false
wait(0.3)
local Crim = Instance.new("Part")
   Crim.Name = "plr"
     Crim.Parent = workspace
       Crim.Anchored = true
         Crim.Archivable = true
      Crim.CFrame = CFrame.new(9e99, 9e99, 9e99)
   Bruh = game.Workspace["Criminals Spawn"].SpawnLocation
Crim.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
	Crim.Transparency = 1
	    Crim.Anchored = true
	 Crim.CanCollide = false
  lol = true				
Bruh = game.Workspace["Criminals Spawn"].SpawnLocation
  Bruh.CanCollide = false
      Bruh.Size = Vector3.new(51.05, 24.12, 54.76)
	Bruh.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
  Bruh.Transparency = 1
  game.Players.LocalPlayer.Character.Humanoid.Sit = false
  wait(0.3)
local Crim = Instance.new("Part")
   Crim.Name = "plr"
     Crim.Parent = workspace
       Crim.Anchored = true
         Crim.Archivable = true
      Crim.CFrame = CFrame.new(9e99, 9e99, 9e99)
   Bruh = game.Workspace["Criminals Spawn"].SpawnLocation
Crim.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
	Crim.Transparency = 1
	    Crim.Anchored = true
	 Crim.CanCollide = false
  lol = true				
Bruh = game.Workspace["Criminals Spawn"].SpawnLocation
  Bruh.CanCollide = false
      Bruh.Size = Vector3.new(51.05, 24.12, 54.76)
	Bruh.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
  Bruh.Transparency = 1
  game.Players.LocalPlayer.Character.Humanoid.Sit = false
end
for i,v in pairs(Workspace.Prison_ITEMS.giver:GetChildren()) do
	if v.Name == "AK-47" then
       lol = Workspace.Remote.ItemHandler:InvokeServer(v.ITEMPICKUP)
	end
end
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
game.Players.LocalPlayer.Character.Humanoid.Name = 1
local l = game.Players.LocalPlayer.Character["1"]:Clone()
if game.Players.LocalPlayer.Character["1"] then
l.Parent = game.Players.LocalPlayer.Character
l.Name = "Humanoid"
wait()
game.Players.LocalPlayer.Character["1"]:Destroy()
game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
game.Players.LocalPlayer.Character.Animate.Disabled = true
end
wait()
game.Players.LocalPlayer.Character.Animate.Disabled = false
game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
	if v.Name == "AK-47" then
game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
end
end
		v.Character.HumanoidRootPart.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
		wait()
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
		until v.TeamColor.Name == "Really red"
wait(0.1)
HERE = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
local A_1 = "\66\114\111\121\111\117\98\97\100\100"
local Event = game:GetService("Workspace").Remote.loadchar
Event:InvokeServer(A_1)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = HERE
until i == 0
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
_G.Crimall = false
end
end
end
end


local Crim = Instance.new("Part")
   Crim.Name = "plr"
     Crim.Parent = workspace
       Crim.Anchored = true
         Crim.Archivable = true
      Crim.CFrame = CFrame.new(9e99, 9e99, 9e99)
   Bruh = game.Workspace["Criminals Spawn"].SpawnLocation

_G.Crimalll = true
local Player = game.Players.LocalPlayer
local cpos = Player.Character.HumanoidRootPart.CFrame
for i,v in pairs(game.Teams.Inmates:GetPlayers()) do
if v and v.Character then
if v.Name ~= Player.Name then
if v.Name ~= "jake11price" then
    repeat
    i = i-1
	repeat
	if v.Character.Humanoid.Sit == true then 
game.Workspace.Remote.ItemHandler:InvokeServer(workspace.Prison_ITEMS.giver["Remington 870"].ITEMPICKUP) 
local A_1 = 
{
	[1] = 
{
	["RayObject"] = Ray.new(Vector3.new(827.412415, 101.489777, 2296.84326), Vector3.new(277.738678, 6.89340925, 287.773712)), 
	["Distance"] = 4.7204174995422, 
	["Cframe"] = CFrame.new(832.049377, 101.392006, 2300.97168, 0.843892097, -0.0554918349, 0.533635378, 0, 0.994636595, 0.103430569, -0.536512911, -0.0872842371, 0.839366019), 
	["Hit"] = v.Character.Head
}, 
	[2] = 
{
	["RayObject"] = Ray.new(Vector3.new(827.412415, 101.489777, 2296.84326), Vector3.new(303.047546, 21.3568707, 260.203888)), 
	["Distance"] = 4.8114862442017, 
	["Cframe"] = CFrame.new(832.390259, 101.550629, 2300.74097, 0.738044441, -0.112958886, 0.665229917, 7.45057971e-09, 0.985887885, 0.16740793, -0.674752235, -0.123554483, 0.727628946), 
	["Hit"] = v.Character.Head
}, 
	[3] = 
{
	["RayObject"] = Ray.new(Vector3.new(827.412415, 101.489777, 2296.84326), Vector3.new(296.800507, 7.00420141, 268.067932)), 
	["Distance"] = 4.444625377655, 
	["Cframe"] = CFrame.new(832.185486, 101.391617, 2300.70264, 0.775115669, -0.0692948848, 0.628007889, 7.45057971e-09, 0.993967533, 0.109675139, -0.631819367, -0.0850109085, 0.770439863), 
	["Hit"] = v.Character.Head
}, 
	[4] = 
{
	["RayObject"] = Ray.new(Vector3.new(827.412415, 101.489777, 2296.84326), Vector3.new(284.930573, 11.9850616, 280.483368)), 
	["Distance"] = 4.6211166381836, 
	["Cframe"] = CFrame.new(832.10083, 101.445007, 2300.86963, 0.820150614, -0.0735745132, 0.567397356, 0, 0.991697431, 0.128593579, -0.572147667, -0.105466105, 0.81334126), 
	["Hit"] = v.Character.Head
}, 
	[5] = 
{
	["RayObject"] = Ray.new(Vector3.new(827.412415, 101.489777, 2296.84326), Vector3.new(294.625824, 2.15741801, 270.538269)), 
	["Distance"] = 4.4639973640442, 
	["Cframe"] = CFrame.new(832.169434, 101.341301, 2300.73438, 0.784266233, -0.0537625961, 0.618090749, -3.7252903e-09, 0.99623847, 0.086654529, -0.620424569, -0.0679602176, 0.781316102), 
	["Hit"] = v.Character.Head
}
}
local A_2 = game.Players.LocalPlayer.Backpack["Remington 870"]
local Event = game:GetService("ReplicatedStorage").ShootEvent
Event:FireServer(A_1, A_2)
Event:FireServer(A_1, A_2)
Event:FireServer(A_1, A_2)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = v.Character.HumanoidRootPart.CFrame
wait(0.3)
local Crim = Instance.new("Part")
   Crim.Name = "plr"
     Crim.Parent = workspace
       Crim.Anchored = true
         Crim.Archivable = true
      Crim.CFrame = CFrame.new(9e99, 9e99, 9e99)
   Bruh = game.Workspace["Criminals Spawn"].SpawnLocation
Crim.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
	Crim.Transparency = 1
	    Crim.Anchored = true
	 Crim.CanCollide = false
  lol = true				
Bruh = game.Workspace["Criminals Spawn"].SpawnLocation
  Bruh.CanCollide = false
      Bruh.Size = Vector3.new(51.05, 24.12, 54.76)
	Bruh.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
  Bruh.Transparency = 1
  game.Players.LocalPlayer.Character.Humanoid.Sit = false
wait(0.3)
local Crim = Instance.new("Part")
   Crim.Name = "plr"
     Crim.Parent = workspace
       Crim.Anchored = true
         Crim.Archivable = true
      Crim.CFrame = CFrame.new(9e99, 9e99, 9e99)
   Bruh = game.Workspace["Criminals Spawn"].SpawnLocation
Crim.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
	Crim.Transparency = 1
	    Crim.Anchored = true
	 Crim.CanCollide = false
  lol = true				
Bruh = game.Workspace["Criminals Spawn"].SpawnLocation
  Bruh.CanCollide = false
      Bruh.Size = Vector3.new(51.05, 24.12, 54.76)
	Bruh.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
  Bruh.Transparency = 1
  game.Players.LocalPlayer.Character.Humanoid.Sit = false
  wait(0.3)
local Crim = Instance.new("Part")
   Crim.Name = "plr"
     Crim.Parent = workspace
       Crim.Anchored = true
         Crim.Archivable = true
      Crim.CFrame = CFrame.new(9e99, 9e99, 9e99)
   Bruh = game.Workspace["Criminals Spawn"].SpawnLocation
Crim.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
	Crim.Transparency = 1
	    Crim.Anchored = true
	 Crim.CanCollide = false
  lol = true				
Bruh = game.Workspace["Criminals Spawn"].SpawnLocation
  Bruh.CanCollide = false
      Bruh.Size = Vector3.new(51.05, 24.12, 54.76)
	Bruh.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
  Bruh.Transparency = 1
  game.Players.LocalPlayer.Character.Humanoid.Sit = false
end
	for i,v in pairs(Workspace.Prison_ITEMS.giver:GetChildren()) do
	if v.Name == "AK-47" then
       lol = Workspace.Remote.ItemHandler:InvokeServer(v.ITEMPICKUP)
	end
end
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
game.Players.LocalPlayer.Character.Humanoid.Name = 1
local l = game.Players.LocalPlayer.Character["1"]:Clone()
l.Parent = game.Players.LocalPlayer.Character
l.Name = "Humanoid"
wait()
game.Players.LocalPlayer.Character["1"]:Destroy()
game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
game.Players.LocalPlayer.Character.Animate.Disabled = true
wait()
game.Players.LocalPlayer.Character.Animate.Disabled = false
game.Players.LocalPlayer.Character.Humanoid.DisplayDistanceType = "None"
for i,v in pairs(game:GetService'Players'.LocalPlayer.Backpack:GetChildren())do
	if v.Name == "AK-47" then
game.Players.LocalPlayer.Character.Humanoid:EquipTool(v)
end
end
		v.Character.HumanoidRootPart.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
		wait()
		game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
		until v.TeamColor.Name == "Really red"
wait(0.1)
HERE = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
local A_1 = "\66\114\111\121\111\117\98\97\100\100"
local Event = game:GetService("Workspace").Remote.loadchar
Event:InvokeServer(A_1)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = HERE
until i == 0
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = NOW
_G.Crimalll = false
end
end
end
end
end)

game:GetService('RunService').Stepped:connect(function()
if _G.Crimall == true then wait()
Crim.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
	Crim.Transparency = 1
	    Crim.Anchored = true
	 Crim.CanCollide = false
  lol = true				
Bruh = game.Workspace["Criminals Spawn"].SpawnLocation
  Bruh.CanCollide = false
      Bruh.Size = Vector3.new(51.05, 24.12, 54.76)
	Bruh.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
  Bruh.Transparency = 1
wait(0.1)
end
end)
game:GetService('RunService').Stepped:connect(function()
if _G.Crimalll == true then wait()
Crim.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
	Crim.Transparency = 1
	    Crim.Anchored = true
	 Crim.CanCollide = false
  lol = true				
Bruh = game.Workspace["Criminals Spawn"].SpawnLocation
  Bruh.CanCollide = false
      Bruh.Size = Vector3.new(51.05, 24.12, 54.76)
	Bruh.CFrame = game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame
  Bruh.Transparency = 1
wait(0.1)
end
end)