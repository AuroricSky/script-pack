--// source: https://v3rmillion.net/showthread.php?tid=1009767
--// credits: In-Line Chat Translator by Aim.

loadstring(game:HttpGetAsync('https://raw.githubusercontent.com/xxaim/ignore/master/translator.lua'))()