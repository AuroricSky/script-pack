--// source: https://v3rmillion.net/showthread.php?tid=1020673
--// Prevail X by 02hacks.
--// Best prison life GUI.

loadstring(game:HttpGet("https://pastebin.com/raw/mHfK0Xk4", true))()