--[[ source: https://v3rmillion.net/showthread.php?tid=1026598
Auratus X Script Hub by MrQuack#8010.
]]
loadstring(game:HttpGet(('https://pastebin.com/raw/mtrRP1H1'),true))()