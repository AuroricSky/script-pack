--[[https://v3rmillion.net/showthread.php?tid=1012881, BIG Paintball GUI by Averias.
]]
loadstring(game.HttpGet(game, "https://pastebin.com/raw/pgnigYpu")) ()