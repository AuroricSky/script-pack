--[[ source: https://v3rmillion.net/showthread.php?tid=1025503
ArsenalHaxx by Serpex.
]]
loadstring(game:HttpGet("https://raw.githubusercontent.com/NougatBitz/ArsenalHaxx/master/Script"))();
