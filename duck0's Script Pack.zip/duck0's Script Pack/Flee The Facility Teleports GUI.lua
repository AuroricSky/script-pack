--[[source: https://v3rmillion.net/showthread.php?tid=825809
Flee The Facility Teleports GUI by kelvin3333.
]]
loadstring(game:HttpGet("https://pastebin.com/raw/mFnVACZ1",true))()