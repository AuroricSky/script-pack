-- script by aim, game: https://www.roblox.com/games/4669056864.
loadstring(game:HttpGet("https://raw.githubusercontent.com/xxaim/ignore/master/source.lua"))();