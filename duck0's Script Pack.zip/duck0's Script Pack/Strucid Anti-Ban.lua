--[[https://v3rmillion.net/showthread.php?tid=1005783, Strucid local anti-ban by payk12
]]
meta = getrawmetatable(game)
nc = meta.__namecall
make_writeable(meta)

meta.__namecall = newcclosure(function(rc, ...)
    args = {...}
    if tostring(rc) == "RemoteEvent" and getnamecallmethod() == "FireServer" and #args >= 6 and (args[2] == 1 or args[2] == 1.1) and args[3] == 5 and args[4] == 5 and args[5] == "Floor" and math.floor(args[6]*100)/100 == math.floor(math.pi/2*100)/100 then
        return
    end
    return nc(rc, ...)
end)
