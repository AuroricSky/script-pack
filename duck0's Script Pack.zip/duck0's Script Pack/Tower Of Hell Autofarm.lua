--[[source: https://v3rmillion.net/showthread.php?tid=1021468
Tower Of Hell Autofarm by GreenedBoi.
]]
loadstring(game:HttpGet(('https://pastebin.com/raw/qyC8rTK1'),true))()