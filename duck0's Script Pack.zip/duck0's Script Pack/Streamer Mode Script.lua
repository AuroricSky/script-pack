--[[https://v3rmillion.net/showthread.php?tid=997569, Streamer Mode Script by NarwhalHacks.
]]
_G.Name = "Nope"
_G.ClearCharacter = true

loadstring(game:HttpGet("http://www.narwhalhacks.xyz/scripts/StreamerMode.lua", true))()