--[[ edit go to robloxscripts com for the best scripts with the thing you want to to spam in chat, enjoy!
]]
while true do wait(1) 

local A_1 = "go to robloxscripts com for the best scripts" local A_2 = "All" 
local Event = game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest Event:FireServer(A_1, A_2) end