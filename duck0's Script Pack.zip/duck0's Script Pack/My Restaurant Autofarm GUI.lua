--[[source: https://v3rmillion.net/showthread.php?tid=1020461
My Restaurant Autofarm GUI by NAME4YOU.
game: https://www.roblox.com/games/4490140733/
]]
loadstring(game:HttpGet('https://pastebin.com/raw/3FPpv84j'))()