--[[https://v3rmillion.net/showthread.php?tid=1014975, Build A Boat For Treasure inf blocks by full.
]]
spawn(function()
local guiinf = game:GetService("Players").LocalPlayer.PlayerGui.BuildGui.InventoryFrame.ScrollingFrame.BlocksFrame
_G.Blocks = false
while game:GetService("RunService").RenderStepped:wait() do
if _G.Blocks then return end
    for i,v in pairs(guiinf:GetDescendants()) do
            if v.Name == "AmountText" then
                v.Text = math.huge
            end
        end
    end
end)