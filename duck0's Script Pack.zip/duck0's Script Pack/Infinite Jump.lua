_G.mj = true
lp = game.Players.LocalPlayer

while wait(0.1) do
    if _G.mj == true and game:GetService('UserInputService'):IsKeyDown(Enum.KeyCode.Space) == true then
        lp.Character:FindFirstChildOfClass('Humanoid'):ChangeState(3)
    end
end