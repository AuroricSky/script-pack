--[[https://robloxscripts.com/phantom-forces-undetected-esp/, Phantom Forces ESP by detourious.
UNDETECTED ESP
hotkeys (us qwerty keyboards):
4 (above R) – changes the font
5 (also above R lol) – toggles esp
]]
loadstring(game:HttpGet("https://pastebin.com/raw/BUZiqqs0"))()

