--[[https://v3rmillion.net/showthread.php?tid=1009284, FE sword script by HTDBarsii.
The sword DOESN'T kill/fling. game/avatar must be R6.
you must have any demonic greatsword 100R$ ex. - https://web.roblox.com/catalog/4506945409/Corrupt-Demonic-Greatsword
video about it:
http://cords-are.xyz/Uploader/i61c.mp4
]]
loadstring(game:HttpGet("https://pastebin.com/raw/f59Kn8tj"))()