--Made by Drex#8176
loadstring(game:HttpGet("https://pastebin.com/raw/maCqrW0g", true))()
