--[[https://v3rmillion.net/showthread.php?tid=990434, Hat Drop Script by eringj.
]]
loadstring(game.HttpGet(game, "https://pastebin.com/raw/ZJqXnz6e")) ()