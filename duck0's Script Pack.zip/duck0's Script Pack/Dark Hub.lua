loadstring(game:HttpGet(("https://pastebin.com/raw/yCrBkPaY"), true))()
