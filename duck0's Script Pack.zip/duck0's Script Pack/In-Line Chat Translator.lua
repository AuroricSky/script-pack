--[[source: https://v3rmillion.net/showthread.php?tid=1009767
In-Line Chat Translator by Aim.
]]
loadstring(game:HttpGetAsync('https://raw.githubusercontent.com/xxaim/ignore/master/translator.lua'))()