--[[source: https://v3rmillion.net/showthread.php?tid=1001035
Skate Park GUI by gamermanaway.
Game Link: https://www.roblox.com/games/4850718823/
]]
loadstring(game:HttpGet("https://pastebin.com/raw/00zfDL5G", true))()