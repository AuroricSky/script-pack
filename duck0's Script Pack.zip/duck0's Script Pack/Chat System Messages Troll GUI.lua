--[[source: https://v3rmillion.net/showthread.php?tid=1018545
Chat System Messages Troll GUI by GetService.
yea turn all the functions on and put in belle delphine and you'll get some results.
]]
loadstring(game:HttpGet("https://pastebin.com/raw/1eRAY7eC",true))()