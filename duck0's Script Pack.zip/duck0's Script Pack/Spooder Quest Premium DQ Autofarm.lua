--[[source:https://raw.githubusercontent.com/Introvert1337/SpooderQuest/master/script.lua
Spooder Quest Premium DQ Autofarm by Introvert#1337 and Username#6969.
game: https://www.roblox.com/games/2414851778/
you can edit your settings from the source link.
**PUT THIS IN YOUR AUTOEXEC FOLDER**
]]
loadstring(game:HttpGet('https://raw.githubusercontent.com/Introvert1337/SpooderQuest/master/script.lua'))()