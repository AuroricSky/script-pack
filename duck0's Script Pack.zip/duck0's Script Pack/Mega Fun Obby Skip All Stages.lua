while wait() do 
    clvl = game.Players.LocalPlayer.leaderstats.Stage.Value + 1
    if game.Workspace.stages:FindFirstChild(tostring(clvl)) then
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Workspace.stages:FindFirstChild(tostring(clvl)).CFrame
    end
    end