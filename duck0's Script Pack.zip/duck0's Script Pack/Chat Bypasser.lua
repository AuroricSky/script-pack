--[[source: https://v3rmillion.net/showthread.php?tid=1006944
Chat Bypasser by Africa Police.
how to use:
say the naughty word you want to say in-chat and it will auto-convert it, enjoy!
i recommend you put this in your autoexec folder.
]]
loadstring(game:HttpGet("https://pastebin.com/raw/JFeVbTv6", true))()
--[[ *List Of Words That Can Be Bypassed* as of 7/1/20. 47 Total. 
nigger 
faggot 
thot 
bitch 
cunt 
fuck
fucker
whore
dick
penis 
asshole 
allahu 
akbar 
crap 
shit 
motherfucker 
girlfriend
boyfriend 
slave 
hoe 
sex  
cum 
pussy 
nigga 
slut 
rape
Terrorist 
Isis
1,2,3,4,5,6,7,8,9,0
Jihad
Holocaust 
Hitler 
Heil
Nazi
Gas the jews
Stalin
Retard
Penis
Vagina
Smegma
Genital
Retarded
Autistic
Ass
Dox
Ur ip is
Nigger Killer
]]