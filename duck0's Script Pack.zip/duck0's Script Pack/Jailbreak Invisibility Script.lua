--[[source: https://discord.gg/b5gtEVX
Jailbreak Invisibility Script by Veernezus#5392.
get close to the dune buggy vehicle at the back of area 51 then execute the script.
]]
loadstring(game:HttpGet("https://pastebin.com/raw/tyfXi2pN ",true))()