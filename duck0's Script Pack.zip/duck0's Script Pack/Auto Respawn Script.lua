--[[https://v3rmillion.net/showthread.php?tid=1009561, 1st reply, auto respawn script by Peyton.
]]
local BackupCFrame = nil
game:GetService("Players").LocalPlayer.CharacterAdded:Connect(function(character)
    local HumanoidRootPart = character:WaitForChild("HumanoidRootPart")
    if BackupCFrame then
        HumanoidRootPart.CFrame = BackupCFrame
    end
    character:WaitForChild("Humanoid").Died:Connect(function()
        BackupCFrame = HumanoidRootPart.CFrame
    end)
end)