--[[https://robloxscripts.com/fe-chill-script/, FE Chill by SmittyHere#2848.
]]
loadstring(game:HttpGet(('https://pastebin.com/raw/CdDw1CUw'),true))()
