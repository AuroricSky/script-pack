--// JumpPower Script
--[[
Q for less JumpPower
E for more JumpPower
--]]

local UIS = game:GetService("UserInputService")

UIS.InputBegan:Connect(function(input)
    if input.keyCode == Enum.KeyCode.E
    then
		game.Players.LocalPlayer.Character.Humanoid.JumpPower = game.Players.LocalPlayer.Character.Humanoid.JumpPower + 5
	elseif input.keyCode == Enum.KeyCode.Q
	then
		game.Players.LocalPlayer.Character.Humanoid.JumpPower = game.Players.LocalPlayer.Character.Humanoid.JumpPower - 5
    end
end)