--// source: https://v3rmillion.net/showthread.php?tid=1006273
--// credits: Phantom Forces Chams by ArilisDev.

getgenv().ESPSettings = {
     Color = Color3.fromRGB(36, 141, 173)
}
loadstring(game:HttpGet('https://arilis.dev/releases/pf_chams.lua', true))()