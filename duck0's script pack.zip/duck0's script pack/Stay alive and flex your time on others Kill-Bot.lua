--// source: https://v3rmillion.net/showthread.php?tid=1045570
--// credits: Stay alive and flex your time on others Kill-Bot by Blockman.
--[[
Features:
auto-kill.
when you die auto the script will teleport you to other/same server.
when your health lower 50 it will stop killing all until you back to 50.

You can set:
sword size.
health limit.
safe zone block high.

You need to do:
put the script at your exploit autoexec file and join the game.
--]]

getgenv().ss = Vector3.new(25,25,25) -- Sword size
getgenv().hl = 50 -- Health limit
getgenv().sz = 17 -- Safe zone high[/align]

-- support server : discord.gg/VDuRyuZ

loadstring(game:HttpGet("https://raw.githubusercontent.com/Kelvinouo/Hub/master/killal"))()