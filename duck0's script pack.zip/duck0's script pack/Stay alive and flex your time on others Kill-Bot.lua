--// source: https://v3rmillion.net/showthread.php?tid=1045570
--// credits: Blockman. i suggest using https://altgen.club/ for this shit cus they got exploit reports. and put this in your autoexec for this to work.

getgenv().ss = Vector3.new(25,25,25) -- Sword size
getgenv().hl = 35 -- Health limit

-- support server: discord.gg/VDuRyuZ

loadstring(game:HttpGet("https://raw.githubusercontent.com/Kelvinouo/Hub/master/killal"))()