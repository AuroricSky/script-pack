--// source: https://v3rmillion.net/showthread.php?tid=1006944
--// credits: Chat Bypasser by Africa Police, improved by ducko.

pcall(function()
    local script = game:HttpGet('https://raw.githubusercontent.com/du3ko/guis/master/Improved%20Chat%20Bypasser.lua')
    assert(loadstring(script))()
end)