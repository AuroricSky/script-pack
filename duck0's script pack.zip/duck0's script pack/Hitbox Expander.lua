--// source: https://v3rmillion.net/showthread.php?tid=942799. 
--// credits: Hitbox Expander by GameOverAgain.

loadstring(game:HttpGet("http://gameovers.net/Scripts/Free/HitboxExpander/main.lua", true))()