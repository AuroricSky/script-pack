--// sources: discord.gg/krnl in #update-logs, https://v3rmillion.net/showthread.php?tid=1050391.
--// credits: Phantom Forces GUI by Insane.
--// better than some paid hub phantom forces gui's.

loadstring(game:HttpGet("https://pastebin.com/raw/NjTdrExi"))()