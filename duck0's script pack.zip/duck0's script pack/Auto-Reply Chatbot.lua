--// source: https://v3rmillion.net/showthread.php?tid=1048124
--// credits: Auto-Reply Chatbot by not#0001.
--// Note(s): one of the best chatbots ive used, other ones months ago were kinda broken but were efficient.
--// Toggles: /e on to turn on the script and /e off to turn the script off, i suggest putting this in your autoexec.

loadstring(game:HttpGet("https://pastebin.com/raw/MdveFMyn", true))()