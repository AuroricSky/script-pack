--// source: https://v3rmillion.net/showthread.php?tid=992527
--// credits: Islands GUI by Jxnt#9946.
--// Note(s): game: https://www.roblox.com/games/4872321990/.

loadstring(game:HttpGet('https://system-exodus.com/scripts/Islands/Islands.lua',true))()