--// from the noobhaxx scripts folder, don't know who made it.

repeat wait() until game:IsLoaded()
local Action = game:service'Players':GetPlayers()
  for i = 1,#Action do
Action[i].Chatted:connect(function(Message)
  game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("".."["..Action[i].Name.."]".." "..Message, "All")
  end)
end