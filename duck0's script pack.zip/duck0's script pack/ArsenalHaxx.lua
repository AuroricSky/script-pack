--// source: https://v3rmillion.net/showthread.php?tid=1025503
--// credits: ArsenalHaxx by Serpex.

loadstring(game:HttpGet("https://raw.githubusercontent.com/NougatBitz/ArsenalHaxx/master/Script"))();