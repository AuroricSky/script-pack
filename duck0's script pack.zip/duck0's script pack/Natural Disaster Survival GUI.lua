--// source: https://v3rmillion.net/showthread.php?tid=1041153
--// credits: redwireplatinum.

loadstring(game:HttpGet("https://raw.githubusercontent.com/redwireplatinum/NDSGUI/master/NDSGUI"))()