--// source: https://v3rmillion.net/showthread.php?tid=1050229
--// credits: Jailbreak Vynixius GUI by RegularVynixu#8039 and Syko#9709.
--// Note(s): better than the jailbreak paypal gui imo, better than some paid scripts in terms of features :)
--// join their discord to get the key: https://discord.me/vynixuhangout

loadstring(game:HttpGet("https://raw.githubusercontent.com/RegularVynixu/Scripts/master/Vynixius%20Jailbreak", true))()