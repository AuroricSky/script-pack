--// source: https://v3rmillion.net/showthread.php?tid=1049691
--// credits: Celestial Universal Silent Aim by yesok#3877.
--// Note(s): Compatible Games List: (a lot): https://cdn.discordapp.com/attachments/753038561787248710/754093307893776435/Compatible_Games_List.txt
-- legit settings
getgenv().SelectedPart = "Torso" -- or Head.
getgenv().VisibiltyCheck = true 
getgenv().TargetESP = true
getgenv().FOV = 50 -- normally its 250 FOV.
getgenv().Distance = 500
loadstring(game:HttpGet("https://raw.githubusercontent.com/yesok3877/Celestial-Silent-Aim/master/Auto-Input", true))()