--// source: https://v3rmillion.net/showthread.php?tid=1055543
--// credits: Assasine03#9403.

loadstring(game:HttpGet("https://pastebin.com/raw/6Z08vuiu", true))()