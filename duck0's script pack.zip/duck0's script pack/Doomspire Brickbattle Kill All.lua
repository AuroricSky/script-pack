--// source: https://v3rmillion.net/showthread.php?tid=932320
--// credits: Doomspire Brickbattle Kill All by ScriptingStefan.
--// This can also work on any sword game since i tested it on the underground war and it worked despite the game having an anticheat. i bet they will patch it one day. ;)

local LP = game:GetService("Players").LocalPlayer
while wait(0.1) do
for i,v in pairs(game:GetService("Players"):GetPlayers()) do
if v and v.Character and v ~= LP and v.Character:FindFirstChild("Head") then
local hrp = v.Character:FindFirstChild("Head") --// I thought of using humanoidrootpart first but it works better with the head!
hrp:BreakJoints()
hrp.Transparency = 0
hrp.BrickColor = v.TeamColor
hrp.Anchored = true
hrp.CanCollide = false
pcall(function()
hrp.CFrame = LP.Character.HumanoidRootPart.CFrame * CFrame.new(1,0,-3.5)
end)
end
end
end