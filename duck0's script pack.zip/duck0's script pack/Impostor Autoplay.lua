--// source: https://v3rmillion.net/showthread.php?tid=1057515
--// credits: Octax.

-- [[ Toggle ]] --
_G.Enabled = true -- Toggles script on and off

-- [[ Imposter ]] --
_G.AutoKill = true -- Automatically kill as imposter
_G.KillType = 1 -- 1) Kill people 2 at a time 2) Kill everyone (Buggy)
_G.AutoSabotage = true -- Automatically Sabotage devices
_G.ChosenSabotage = 1 -- If auto sabotage is enabled this will pick a certain sabotage to trigger 1) Oxygen 2) Reactor 3) Communications 4) Lighting
_G.AutoLockDoors = true -- Automatically lock doors

-- [[ Innocent ]] --
_G.AutoFixSabotage = true -- Automatically fix sabotaged devices
_G.AutoTask = true -- Automatically completes tasks for you

-- [[ General ]] --
_G.HidePlayer = true -- Hides you at lobby

-- [[ Code - Obfuscated with PSU https://www.psu.dev/ & discord.gg/psu ]] --
loadstring(game:HttpGet("https://raw.githubusercontent.com/0ctax/ROBLOX-Scripts/master/Impostor!/Obfuscated_Auto_Play.lua"))()