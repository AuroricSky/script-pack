--// source: https://v3rmillion.net/showthread.php?tid=1050185
--// credits: Unit Classified Kill All by LittleDyingDuck.
--// Note(s): eheheh little duck.

local tbl = {}
local primgun = {}
local rs = game:GetService("RunService")
rs.Heartbeat:connect(function()
for i,v in pairs(game.Players:GetPlayers()) do
   if v ~= game.Players.LocalPlayer.Team then
       if v ~= game.Players.LocalPlayer then
           table.insert(tbl, v.Name)
       end
   end
end
function getprim()
   table.insert(primgun, tostring(game:GetService("Players").LocalPlayer.Loadout.Primary.Value))
end

getprim()
local A_1 =  {
   [1] = "hitpart",
   [2] = game:GetService("Workspace").Players[tbl[math.random(#tbl)]].Head,
   [3] = game:GetService("ReplicatedStorage").Weapons[primgun[math.random(#primgun)]],
   [4] = 999999
}
local Event = game:GetService("ReplicatedStorage").Events.ME
Event:FireServer(A_1)
end)