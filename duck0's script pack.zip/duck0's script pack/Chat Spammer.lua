--// source: https://robloxscripts.com/chat-spam-script/
--// credits: unknown.
--// edit "i taste like cheese" with the thing you want to to spam in chat.

repeat wait() until game:IsLoaded()
while true do wait(3) 
    local A_1 = "i taste like cheese" local A_2 = "All" 
    local Event = game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest Event:FireServer(A_1, A_2) 
end