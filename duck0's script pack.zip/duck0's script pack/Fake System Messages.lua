--// source: https://v3rmillion.net/showthread.php?tid=1018516
--// credits: Fake System Messages by ShedIetsky.
--// scroll to the right to edit the system message, also the second line is fully customizable so you can say "{System} Your friend Coronavirus has infected the game." instead of "{System} Your friend ROBLOX has joined the game." and don't edit the space obviously.

local A_1 = "hi                                                                                                                                              {System} Your friend ROBLOX has joined the game."
local A_2 = "All"
local Event = game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest
Event:FireServer(A_1, A_2)