------------------
--   By Avakir  --
--     v1.1     --
------------------
-- https://v3rmillion.net/showthread.php?tid=1055768 --

-- In the first npc you can get stuck but just wait.
-- If you're floating in the air in a faraway place it means you're waiting for missions.
-- Your exploit need the clickdetector function for auto scroll (only tested with synapse x and proto).
-- Feel free to adjust the settings.

shared.On = true
shared.Settings = {
   AllowBoss = false,
   PlayerHeight = CFrame.new(0,-15,0),
   KillDelay = 0.5, -- If it continues to freeze, increase the time.
   TweenSpeedDelay = 1,-- The less the value, the faster it will be / If it continues to freeze, increase the time.
   WaitWhenKill = false
}

loadstring(game:HttpGet("https://pastebin.com/raw/2ssbn6LV", true))()