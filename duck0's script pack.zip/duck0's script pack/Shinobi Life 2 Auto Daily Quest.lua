-- source: https://v3rmillion.net/showthread.php?tid=1057609 --
-- made by Walter#7772/CrrackHead --

_G.AutoRush = true
_G.AutoChakra = true
_G.AutoPunch = true
_G.AutoTreeJump = true

rush = 100 --- amount of how many times you want it to rush
chakra = 100 --- amount of how many times you want it to charge your chakra
punch = 100 --- amount of how many times you want it to punch
TreeJump = 100 --- amount of how many times you want it to TreeJump

loadstring(game:HttpGet("https://pastebin.com/raw/0feFJJmc"))();