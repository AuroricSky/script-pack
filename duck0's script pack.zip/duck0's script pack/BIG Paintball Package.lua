--// source: https://v3rmillion.net/showthread.php?tid=1009854
--// credits: JasonJJK.

loadstring(game:HttpGet("https://pastebin.com/raw/sfrV9GgJ"))()