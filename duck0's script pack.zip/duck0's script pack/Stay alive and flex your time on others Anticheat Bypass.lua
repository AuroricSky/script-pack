--// source: https://v3rmillion.net/showthread.php?tid=1057314
--// credits: Blockman. Put this in your autoexec for this to work.

loadstring(game:HttpGet(('https://pastebin.com/raw/tPXuwU7J'),true))()