-- Toggle: E.
loadstring(game:HttpGetAsync("https://pastebin.com/raw/YqCND4QS"))()