--// source: https://v3rmillion.net/showthread.php?tid=1052038
--// credits: Bitz#1000.

loadstring(game:HttpGet('https://raw.githubusercontent.com/NougatBitz/DuckHub/master/Main.lua'))()