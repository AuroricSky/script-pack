--// source: https://v3rmillion.net/showthread.php?tid=1046680
--// credits: Stay alive and flex your time on others Script by BeachBear.

pcall(function()
    local source = game:HttpGetAsync('https://pastebin.com/raw/3gzYrgM0')
    assert(loadstring(source))()
end)