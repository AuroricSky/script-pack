--// source: https://discord.gg/mHZavDq
--// credits: Infinite Yield by Edge#2928.
--// i know theres more people working on it but im too lazy to list all of them.

loadstring(game:HttpGet('https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source'))()