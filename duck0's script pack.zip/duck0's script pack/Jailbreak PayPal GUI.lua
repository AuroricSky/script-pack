--// source: https://discord.gg/uKNgJ5K
--// credits: Jailbreak PayPal GUI by Hazed#0001.

loadstring(game:HttpGet("https://raw.githubusercontent.com/HazeWasTaken/JailedHax/master/PayPal", true))()