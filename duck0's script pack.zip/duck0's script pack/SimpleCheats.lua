--// simpleCheats GUI by @duck0#0415.
--// source: https://github.com/du3ko/scripts/blob/master/simpleCheats.lua
--// alternative loadstring if pastebin chokes: loadstring(game:HttpGet("https://raw.githubusercontent.com/du3ko/scripts/master/simpleCheats.lua", true))()

loadstring(game:HttpGet("https://pastebin.com/raw/cUvMssVP", true))()