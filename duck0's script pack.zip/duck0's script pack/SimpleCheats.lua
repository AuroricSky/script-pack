--// simpleCheats GUI by @duck0#0415.
--// alternative loadstring if pastebin chokes: loadstring(game:HttpGet('https://raw.githubusercontent.com/du3ko/scripts/master/simpleCheats.lua'))()

loadstring(game:HttpGet('https://pastebin.com/raw/cUvMssVP'))()