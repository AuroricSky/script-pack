--// HipHeight Script
--[[
Q for less HipHeight
E for more HipHeight
--]]

local UIS = game:GetService("UserInputService")

UIS.InputBegan:Connect(function(input)
    if input.keyCode == Enum.KeyCode.E
    then
		game.Players.LocalPlayer.Character.Humanoid.HipHeight = game.Players.LocalPlayer.Character.Humanoid.HipHeight + 5
	elseif input.keyCode == Enum.KeyCode.Q
	then
		game.Players.LocalPlayer.Character.Humanoid.HipHeight = game.Players.LocalPlayer.Character.Humanoid.HipHeight - 5
    end
end)