--// source: https://discord.gg/Gf3jJym and https://www.youtube.com/watch?v=EDLRf4ICGik
--// credits: FE Building Tools by UFOpilot#6075 and maybe other people.
--// BIG NOTE: join the discord server here: https://discord.gg/Gf3jJym to get the key.
--// this is my setup, you can set the G switches to whatever customization you like.

_G.CheckCustomBuilds = true
_G.DefaulBuilds = true
_G.Barrier = true
_G.bridge2 = false
_G.bridge4 = false
_G.ladder = true
_G.Nazi = true
_G.penis = true
_G.platform = false
_G.stairs = true
_G.BigPP = true

_G.RGB = false
_G.RGBswitchDelay = .4

_G.RejoinWaitDelayForReExecute = 0.1  -- tell how long the script will wait before rejoining (for synapse script queing)

loadstring(game:HttpGet("https://ssbtools.netlify.app/assets/storage/LOADSTRING_SCRIPT2.txt"))()