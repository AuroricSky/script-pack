--// source: https://v3rmillion.net/showthread.php?tid=990897
--// credits: Prison Life Car Spammer by Duck Guy.
--// click around and cars will rain.

game:GetService("RunService").RenderStepped:Connect(function()
    game.Players.LocalPlayer.SimulationRadius = math.huge
    game.Players.LocalPlayer.MaximumSimulationRadius = math.huge
    end)
    game.StarterGui:SetCore("SendNotification", {Title = "Credits"; Text = "Discord - Voyager#3458       V3rmillion - Duck Guy"; Duration = 5})
    local Mouse = game.Players.LocalPlayer:GetMouse()
    Mouse.Button1Down:Connect(function(hit)
    for i,v in pairs(workspace.Prison_ITEMS.buttons:GetDescendants()) do
    if v.Name == "Car Spawner" and v.ClassName == "Part" then
    workspace.Remote.ItemHandler:InvokeServer(v)
    end
    end
    wait(.5)
    for i,v in pairs(workspace.CarContainer:GetChildren()) do
    v:MoveTo(Mouse.hit.p)
    v.Parent = workspace
    end
    end)