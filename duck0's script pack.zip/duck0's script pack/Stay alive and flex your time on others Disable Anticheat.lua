--// source: https://v3rmillion.net/showthread.php?tid=1045344
--// credits: below.
--[[
    Made by Megumu / egg salad
    <3
]]
repeat wait() until game:IsLoaded() --so it always executes guaranteed.
-- Grab their module
local mod
for i,v in pairs(getnilinstances()) do
    if v:IsA("ModuleScript") then
        mod = v
        break
    end
end

-- Skeet
for i,v in pairs(getgc(true)) do
    if typeof(v) == "function" and getfenv(v).script == mod and table.find(debug.getconstants(v), "coroutine") then
        hookfunction(v, function(reason)
            warn("game tried to kick for:",reason)
            return wait(1e19)
        end)
    end
end 