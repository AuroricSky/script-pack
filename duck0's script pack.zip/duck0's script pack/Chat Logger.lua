--// source: https://v3rmillion.net/showthread.php?tid=959780
--// credits: Chat Logger by find.
--// chat logs will appear in your workspace folder.

_G.XXIlogname = true --Shows the name of the player that sent the message
_G.XXIlogtime = false --Shows the time the player sent the message
_G.XXIlogdate = false --Shows the date the player sent the message
_G.XXIlogmembership = false --Shows players membership status. Either premium or none
_G.XXIloguid = true --The unique ID of the player
_G.XXIlogserverid = false --The unique ID of the server
_G.XXIlogaccage = true --The date the account the player is using was created
_G.XXIlogposition = false --Players positions at the time they chatted
loadstring(game:HttpGet(('https://pastebin.com/raw/GU4AjcYh'),true))()