--// source: https://v3rmillion.net/showthread.php?tid=995325
--// credits: Hide and Seek Extreme GUI by JasonJJK and Copper.
--// Game Link: https://www.roblox.com/games/205224386/.

lIIIlllllllllIIIllII,lIllIllIlIIlIllIllII=game,loadstring;lIllIllIlIIlIllIllII(lIIIlllllllllIIIllII['\72t\116p\71e\116'](lIIIlllllllllIIIllII,'\104t\116p\115:\47/\114a\119.\103i\116h\117b\117s\101r\99o\110t\101n\116.\99o\109/\74a\115o\110J\74K\47i\108l\73i\105I\108l\73I\108i\108l\73i\73l\105i\73i\105l\108l\108l\108i\73l\108l\108i\105I\73i\105I\73I\105I\105i\105i\105i\105l\105l\108I\105I\108l\73I\73l\105I\73i\73I\108i\105l\108i\73i\108i\105i\105I\73I\105I\73i\108i\105l\108i\105/\109a\115t\101r\47H\97S\71U\73'))()